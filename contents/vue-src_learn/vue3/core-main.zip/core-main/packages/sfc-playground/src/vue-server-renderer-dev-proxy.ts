// serve vue/server-renderer to the iframe sandbox during dev.
export * from 'vue/server-renderer'
